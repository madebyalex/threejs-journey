import React from "react";
import ReactDOM from "react-dom";
import App from "./script";

// React entry point that binds to html
ReactDOM.render(<App />, document.getElementById("root"));
