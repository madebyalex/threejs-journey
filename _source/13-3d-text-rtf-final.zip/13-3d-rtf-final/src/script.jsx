import React, { forwardRef, Suspense, useEffect, useMemo, useRef } from "react"
import * as THREE from "three"
import { Canvas, useFrame, extend, useThree, useLoader, useUpdate } from "react-three-fiber"
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'

import './style.css'
extend({OrbitControls})

const TextGeometry = ({matcapTexture}) => {
  const font = useLoader(THREE.FontLoader, '/fonts/helvetiker_regular.typeface.json')
  const config = useMemo(() => ({
    font,
    size: 0.5,
    height: 0.7,
    curveSegments: 5,
    bevelEnabled: true,
    bevelThickness: 0.03,
    bevelSize: 0.02,
    bevelOffset: 0,
    bevelSegments: 4
  }), [])

  const meshRef = useUpdate((mesh) => {
    // mesh.geometry.computeBoundingBox()
    // mesh.geometry.translate(
    //     -(mesh.geometry.boundingBox.max.x - 0.02) * 0.5,
    //     -(mesh.geometry.boundingBox.max.y - 0.02) * 0.5,
    //     -(mesh.geometry.boundingBox.max.z - 0.02) * 0.5
    // )
    mesh.geometry.center()
    mesh.geometry.computeBoundingBox()
  }, [])

  return(
    <mesh ref={meshRef}>
      <textGeometry args={['My house', config]} />
      <meshMatcapMaterial matcap={matcapTexture}/>
    </mesh>
  )
}

const Torus = ({geometry, material}) => {
  const scale = useMemo(() => Math.random() * 2, [])

  return <mesh
    geometry={geometry}
    material={material}
    position={[(Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 10]}
    rotation-x={Math.random() * Math.PI}
    rotation-y={Math.random() * Math.PI}
    scale={[scale, scale, scale]}
     />
}

const LocalScene = () => {
  // Create a reference of the orbit controls
  const controlsRef = useRef();

  // Get the orbitControls constructo arguments, camera and dom element
  const {
    camera,
    gl: { domElement }
  } = useThree();

  // Comment this useFrame code if using MOUSE MOVE CONTROL
  // Update the orbitControl REF to add the damping
  useFrame(() => {
    controlsRef?.current.update()
  })

  const matcapTexture = useLoader(THREE.TextureLoader, '/textures/matcaps/8.png')

  const { count, geometry, material } = useMemo(() => {
      const count = 200;
      const geometry = new THREE.TorusGeometry(0.24, 0.1, 24, 48)
      const material = new THREE.MeshMatcapMaterial()
      return {
        count,
        geometry,
        material
      }
  }, [])

  useMemo(() => material.matcap = matcapTexture, [])

  return (
    <>
      <TextGeometry matcapTexture={matcapTexture} />
      {/* Not sure if i like this or not... */}
      {Array(count).fill().map((_, i) => (
        <Torus key={i} geometry={geometry} material={material} matcapTexture={matcapTexture} />
      ))}
      {/* Comment orbitControls code if you are using the  */}
      <orbitControls ref={controlsRef} args={[camera, domElement]} enableDamping />
    </>
  )
}

export default () => {
  // Create the canvas see API for all defaults that are added by React Three Fiber
  // https://github.com/pmndrs/react-three-fiber/blob/master/markdown/api.md
  return (
    <Canvas
      shadowMap={false}
      gl={{ alpha: false, antialias: false }}
      // We can change the camera defaults here
      // camera={{ position: [2, 2, 2], near: 0.1, far: 100 }}
    >
      <Suspense fallback={null}>
        <LocalScene />
      </Suspense>
    </Canvas>
  )
}
